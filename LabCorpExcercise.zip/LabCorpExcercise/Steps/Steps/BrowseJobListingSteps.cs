using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support;
using TechTalk.SpecFlow;
using System.IO;
using OpenQA.Selenium.Support.Extensions;

namespace YourNamespace
{
    [Binding]
    public class BrowseJobListingSteps
    {
        private IWebDriver driver;
        private WebDriverWait wait;
         

        [BeforeScenario]
        public void Setup()
        {
            // Set up Chrome driver
            driver = new ChromeDriver();
        }

        [AfterScenario]
        public void TearDown()
        {
            driver.Quit();
        }

         [AfterStep]
         public void AfterStep()
            {       
        // Generate a unique name for the screenshot
                var screenshotName = DateTime.Now.ToString("yyyyMMddHHmmss");

        // Capture the screenshot
                ScreenshotHelper.TakeScreenshot(driver, screenshotName);
            }

        [Given(@"I am on the LabCorp website")]
        public void GivenIAmOnTheLabCorpWebsite()
        {
            driver.Navigate().GoToUrl("https://www.labcorp.com");
            driver.Manage().Window.Maximize();
        }

        [When(@"I click on the Careers link")]
        public void WhenIClickOnTheCareersLink()
        {
            var careersLink = driver.FindElement(By.LinkText("Careers"));
            careersLink.Click();
        }

        [When(@"I search for a specific job position")]
        public void WhenISearchForASpecificJobPosition()
        {
            var searchInput = driver.FindElement(By.Id("typehead"));
            searchInput.SendKeys("Adminstrative");
            searchInput.SendKeys(Keys.Enter);
        }

        [When(@"I select and browse to the position")]
        public void WhenISelectAndBrowseToThePosition()
        {
           var jobListingLink = driver.FindElement(By.XPath("//div[@class='job-title']/span[contains(text(),'Data Management Coordinator')]"));
           jobListingLink.Click();
        }

        [Then(@"I should see the correct job details")]
        public void ThenIShouldSeeTheCorrectJobDetails()
        {
            Assert.AreEqual("Data Management Coordinator", driver.FindElement(By.CssSelector(".job-title")).Text);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".job-location")).Text.Contains("Location"));
            Assert.IsTrue(driver.FindElement(By.CssSelector(".job-description p")).Text.Contains("Labcorp is proud to be an Equal"));
            }

        [Then(@"I should be able to apply for the job")]
        public void ThenIShouldBeAbleToApplyForTheJob()
        {
            var applyNowButton = driver.FindElement(By.XPath("//a[@class='btn primary-button au-target']"));
            applyNowButton.Click();
            Assert.AreEqual("Data Management Coordinator", driver.FindElement(By.CssSelector(".job-title")).Text);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".job-location")).Text.Contains("Location"));
        }

        [Then(@"I should be able to return to the job search")]
        public void ThenIShouldBeAbleToReturnToTheJobSearch()
        {
            string currentWindow = driver.CurrentWindowHandle;
            List<string> allWindows = driver.WindowHandles.ToList();
            
            foreach (string window in allWindows)
                {
                    driver.SwitchTo().Window(window);
                    if (driver.Title == "Workday")
                        {
                            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
                            var returnToJobSearchButton = driver.FindElement(By.XPath("//button[contains(text(), 'Careers Home')]"));
                            returnToJobSearchButton.Click();
                        }
                }
           
        }
    }
}
