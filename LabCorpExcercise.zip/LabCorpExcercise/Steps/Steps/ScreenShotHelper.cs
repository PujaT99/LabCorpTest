using System;
using System.IO;
using OpenQA.Selenium;

public class ScreenshotHelper
{
    public static void TakeScreenshot(IWebDriver driver, string screenshotName)
    {
        // Cast the driver to ITakesScreenshot
        var screenshotDriver = (ITakesScreenshot)driver;

        // Take the screenshot as base64 string
        var screenshot = screenshotDriver.GetScreenshot();

        // Define the screenshot file path and name
        var screenshotPath = Path.Combine(
            @"C:\LabCorpExcercise\Steps",
            $"{screenshotName}.png"
        );

        // Save the screenshot to the file path
        screenshot.SaveAsFile(screenshotPath, ScreenshotImageFormat.Png);
    }
}